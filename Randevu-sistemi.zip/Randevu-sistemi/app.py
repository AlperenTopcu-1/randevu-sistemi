from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)
import os
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SECRET_KEY'] = 'gizli-anahtar-super-gizli'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'randevu_v2.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# --- MODELLER ---

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    # Role: 'customer' or 'business_owner'
    role = db.Column(db.String(50), nullable=False, default='customer') 
    
    # Relationships
    business = db.relationship('Business', backref='owner', uselist=False)
    appointments = db.relationship('Appointment', backref='customer', lazy=True)

class Business(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    # Type: 'barber', 'cafe', 'gym', etc.
    type = db.Column(db.String(50), nullable=False) 
    type = db.Column(db.String(50), nullable=False) 
    description = db.Column(db.Text)
    open_time = db.Column(db.String(5), default='09:00') # HH:MM
    close_time = db.Column(db.String(5), default='18:00') # HH:MM
    
    resources = db.relationship('Resource', backref='business', lazy=True)

class Resource(db.Model):
    """
    Örnek: "Masa 1" (Kafe), "Ahmet Usta" (Berber), "Koşu Bandı 3" (Spor Salonu)
    """
    id = db.Column(db.Integer, primary_key=True)
    business_id = db.Column(db.Integer, db.ForeignKey('business.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    capacity = db.Column(db.Integer, default=1) # Kaç kişilik? (Masa için önemli)

    appointments = db.relationship('Appointment', backref='resource', lazy=True)

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    resource_id = db.Column(db.Integer, db.ForeignKey('resource.id'), nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default='confirmed') # confirmed, cancelled

    def check_conflict(resource_id, start, end):
        """Çakışma var mı diye kontrol eder"""
        collision = Appointment.query.filter_by(resource_id=resource_id, status='confirmed').filter(
            Appointment.start_time < end,
            Appointment.end_time > start
        ).first()
        return collision is not None

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- ROTALAR ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            if user.role == 'business_owner':
                return redirect(url_for('business_dashboard'))
            else:
                return redirect(url_for('customer_dashboard'))
        else:
            flash('Giriş başarısız. Lütfen bilgilerinizi kontrol edin.', 'danger')
            
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Çıkış yapıldı.', 'info')
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role') # 'customer' or 'business_owner'
        
        hashed_password = generate_password_hash(password)
        new_user = User(username=username, email=email, password=hashed_password, role=role)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Kayıt başarılı! Giriş yapabilirsiniz.', 'success')
            return redirect(url_for('login'))
        except:
            db.session.rollback()
            flash('Bu email veya kullanıcı adı zaten kullanılıyor.', 'warning')
            
    return render_template('register.html')

@app.route('/dashboard/business', methods=['GET', 'POST'])
@login_required
def business_dashboard():
    if current_user.role != 'business_owner':
        return redirect(url_for('index'))
    
    # İşletme profilini bul veya oluştur
    business = Business.query.filter_by(owner_id=current_user.id).first()
    
    if request.method == 'POST':
        # Yeni işletme oluşturma veya güncelleme
        name = request.form.get('name')
        b_type = request.form.get('type')
        desc = request.form.get('description')
        
        if not business:
            business = Business(owner_id=current_user.id, name=name, type=b_type, description=desc)
            business.open_time = request.form.get('open_time', '09:00')
            business.close_time = request.form.get('close_time', '18:00')
            db.session.add(business)
        else:
            business.name = name
            business.type = b_type
            business.name = name
            business.type = b_type
            business.description = desc
        
        # Saatleri güncelle
        business.open_time = request.form.get('open_time')
        business.close_time = request.form.get('close_time')
        
        db.session.commit()
        flash('İşletme bilgileri güncellendi.', 'success')

    return render_template('business_dashboard.html', business=business)

@app.route('/resource/add', methods=['POST'])
@login_required
def add_resource():
    business = Business.query.filter_by(owner_id=current_user.id).first()
    if business:
        name = request.form.get('name')
        capacity = request.form.get('capacity')
        new_res = Resource(business_id=business.id, name=name, capacity=capacity)
        db.session.add(new_res)
        db.session.commit()
    return redirect(url_for('business_dashboard'))

@app.route('/resource/delete/<int:res_id>', methods=['POST'])
@login_required
def delete_resource(res_id):
    resource = Resource.query.get_or_404(res_id)
    
    # Yetki kontrolü
    if resource.business.owner_id != current_user.id:
        flash('Bu işlem için yetkiniz yok!', 'danger')
        return redirect(url_for('index'))
    
    # Önce bu kaynağa ait randevuları sil
    Appointment.query.filter_by(resource_id=res_id).delete()
    
    db.session.delete(resource)
    db.session.commit()
    flash('Kaynak ve ilgili randevular silindi.', 'warning')
    return redirect(url_for('business_dashboard'))

@app.route('/dashboard/customer')
@login_required
def customer_dashboard():
    if current_user.role != 'customer':
        return redirect(url_for('index'))
    
    businesses = Business.query.all()
    return render_template('customer_dashboard.html', businesses=businesses)

@app.route('/book/<int:business_id>', methods=['GET', 'POST'])
@login_required
def book_appointment(business_id):
    business = Business.query.get_or_404(business_id)
    
    if request.method == 'POST':
        resource_id = request.form.get('resource_id')
        date_str = request.form.get('date') # YYYY-MM-DD
        time_str = request.form.get('time') # HH:MM
        
        start_datetime = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
        # Basitlik için randevular 1 saatlik olsun
        from datetime import timedelta
        end_datetime = start_datetime + timedelta(hours=1)
        
        # Saat kontrolü
        open_t = datetime.strptime(business.open_time, "%H:%M").time()
        close_t = datetime.strptime(business.close_time, "%H:%M").time()
        req_time = start_datetime.time()
        
        if req_time < open_t or req_time >= close_t:
             flash(f'İşletme bu saatlerde kapalı! ({business.open_time} - {business.close_time})', 'danger')
        elif Appointment.check_conflict(resource_id, start_datetime, end_datetime):
            flash('Bu saat aralığı dolu! Lütfen başka bir saat veya masa/koltuk seçin.', 'danger')
        else:
            new_app = Appointment(
                user_id=current_user.id,
                resource_id=resource_id,
                start_time=start_datetime,
                end_time=end_datetime
            )
            db.session.add(new_app)
            db.session.commit()
            flash(f'{start_datetime} için randevunuz oluşturuldu!', 'success')
            return redirect(url_for('customer_dashboard'))

    return render_template('booking.html', business=business)

@app.route('/appointment/cancel/<int:app_id>', methods=['POST'])
@login_required
def cancel_appointment(app_id):
    appointment = Appointment.query.get_or_404(app_id)
    
    # Yetki kontrolü: Sadece randevuyu alan kişi veya işletme sahibi iptal edebilir
    is_customer = appointment.user_id == current_user.id
    is_business_owner = appointment.resource.business.owner_id == current_user.id
    
    if not (is_customer or is_business_owner):
        flash('Bu işlem için yetkiniz yok!', 'danger')
        return redirect(url_for('index'))
    
    appointment.status = 'cancelled'
    db.session.commit()
    flash('Randevu iptal edildi.', 'info')
    
    if is_business_owner:
        return redirect(url_for('business_dashboard'))
    else:
        return redirect(url_for('customer_dashboard'))

@app.route('/appointment/delete/<int:app_id>', methods=['POST'])
@login_required
def delete_appointment(app_id):
    appointment = Appointment.query.get_or_404(app_id)
    
    # Yetki kontrolü
    is_customer = appointment.user_id == current_user.id
    is_business_owner = appointment.resource.business.owner_id == current_user.id
    
    if not (is_customer or is_business_owner):
        flash('Bu işlem için yetkiniz yok!', 'danger')
        return redirect(url_for('index'))
    
    db.session.delete(appointment)
    db.session.commit()
    flash('Randevu kaydı silindi.', 'warning')
    
    if is_business_owner:
        return redirect(url_for('business_dashboard'))
    else:
        return redirect(url_for('customer_dashboard'))

# Veritabanını oluşturma komutu
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
